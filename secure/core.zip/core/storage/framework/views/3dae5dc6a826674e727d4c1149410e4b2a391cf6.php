<?php
    $faqs = getContent('faq.element');
    $faqContent = getContent('faq.content',true);
?>
<!-- faq-section start -->
<section class="faq-section pt-150 pb-150">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-header text-center">
                    <h2 class="section__title"><?php echo app('translator')->get(@$faqContent->data_values->heading); ?></h2>
                    <p><?php echo app('translator')->get(@$faqContent->data_values->sub_heading); ?></p>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="accordion cmn-accordion style--two" id="categoryAccordion">
                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card">
                        <div class="card-header" id="h-<?php echo e($k); ?>">
                            <button class="acc-btn" type="button" data-toggle="collapse" data-target="#c-<?php echo e($k); ?>" aria-expanded="<?php echo e(($k==0) ? 'true':'false'); ?>" aria-controls="c-<?php echo e($k); ?>">
                                <span class="text"><?php echo e(__(@$data->data_values->question)); ?></span>
                            </button>
                        </div>
                        <div id="c-<?php echo e($k); ?>" class="collapse <?php echo e(($k==0) ? 'show':''); ?> " aria-labelledby="h-<?php echo e($k); ?>" data-parent="#categoryAccordion">
                            <div class="card-body">
                                <p><?php echo @$data->data_values->answer ?>


                                <?php echo e(__(@$data->data_values->answer)); ?>


                            </p>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</section>
<!-- faq-section end -->



<?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/neo_dark/sections/faq.blade.php ENDPATH**/ ?>