<?php
    $subscribeContent = getContent('subscribe.content',true);
?>

<!--=======Subscribe-Section Starts Here=======-->
<section class="newsletter-section  pt-150  pb-150 " id="subscribe">
    <div class="container">
        <div class="row justify-content-center text-center">
            <div class="col-lg-7">
                <div class="section-header margin-olpo">
                    <h2 class="section__title"><?php echo app('translator')->get(@$subscribeContent->data_values->heading); ?></h2>
                    <p><?php echo app('translator')->get(@$subscribeContent->data_values->sub_heading); ?></p>
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-7">
                <form class="newslater-form" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="email" name="email" placeholder="<?php echo app('translator')->get('Email Address'); ?>">
                    <button type="submit">
                        <i class="fa fa-paper-plane"></i>
                    </button>
                </form>
            </div>
        </div>
    </div>
</section>
<!--=======Subscribe-Section Ends Here=======-->

<?php $__env->startPush('script'); ?>
<script type="text/javascript">

    (function ($) {
        "use strict";
            $('.newslater-form').on('submit',function(e){

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });


                e.preventDefault();
                var email = $('input[name=email]').val();
                $.post('<?php echo e(route('subscribe')); ?>',{email:email}, function(response){
                    if(response.errors){
                        for (var i = 0; i < response.errors.length; i++) {
                            iziToast.error({message: response.errors[i], position: "topRight"});
                        }
                    }else{
                        iziToast.success({message: response.success, position: "topRight"});
                    }
                });
            });

    })(jQuery);
</script>
<?php $__env->stopPush(); ?><?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/neo_dark/sections/subscribe.blade.php ENDPATH**/ ?>