<?php
    $topInvestor = \App\Models\Invest::with('user')
               ->selectRaw('SUM(amount) as totalAmount, user_id')
               ->orderBy('totalAmount', 'desc')
               ->groupBy('user_id')
               ->limit(6)
               ->get()->toArray();

    $top_investorContent = getContent('top_investor.content',true);
?>

<!-- investor-section start -->
<section class="investor-section pb-150 pt-150">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-header text-center">
                    <h2 class="section__title"><?php echo app('translator')->get(@$top_investorContent->data_values->heading); ?></h2>
                    <p><?php echo app('translator')->get(@$top_investorContent->data_values->sub_heading); ?></p>
                </div><!-- section-header end -->
            </div>
        </div>
        <div class="investor-slider-area">
            <div class="investor-slider">
                <?php $__currentLoopData = $topInvestor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="investor-item">
                        <div class="investor-item__thumb">
                            <img src="<?php echo e(getImage('assets/images/user/profile/'. @json_decode(json_encode($data['user']['image'])), '800x800')); ?>"  alt="image">
                        </div>
                        <div class="investor-item__content">
                            <h3 class="investor__name text-shadow"><?php echo e(@json_decode(json_encode($data['user']['username']))); ?></h3>
                            <p><?php echo app('translator')->get('Total Invest'); ?> <span lass="amount"><?php echo e($general->cur_sym); ?><?php echo e($data['totalAmount']); ?></span></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<!-- investor-section end -->


<?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/neo_dark/sections/top_investor.blade.php ENDPATH**/ ?>