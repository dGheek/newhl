<?php
    $testimonial = getContent('testimonial.element');
    $testimonialContent = getContent('testimonial.content',true);
?>

<!-- testimonial-section start -->
<section class="testimonial-section pb-150 pt-150">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="section-header text-center">
                    <h2 class="section__title"><?php echo app('translator')->get(@$testimonialContent->data_values->heading); ?></h2>
                    <div class="header__divider">
                        <span class="left-dot"></span>
                        <span class="right-dot"></span>
                    </div>
                    <p><?php echo app('translator')->get(@$testimonialContent->data_values->sub_heading); ?></p>
                </div><!-- section-header end -->
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="testimonial-slider-area">
                    <div class="testimonail-slider">
                        <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="testimonial-single">
                            <div class="client__thumb"><img src="<?php echo e(getImage('assets/images/frontend/testimonial/'.@$data->data_values->image)); ?>" alt="image"></div>
                            <i class="flaticon-quotation"></i>
                            <p> <?php echo e(__(@$data->data_values->quote)); ?></p>
                            <h4 class="client__name"><?php echo e(__(@$data->data_values->author)); ?></h4>
                            <span class="designation"><?php echo e(__(@$data->data_values->designation)); ?></span>
                        </div><!-- testimonial-single end -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- testimonial-section end  -->
<?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/neo_dark/sections/testimonial.blade.php ENDPATH**/ ?>