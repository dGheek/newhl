<?php
    $bannerCaption = getContent('banner.content',true);
?>
<!-- hero-section start -->
<section class="hero-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="hero-content">
                    <h2 class="hero__title"><?php echo e(__(@$bannerCaption->data_values->heading)); ?></h2>
                    <p><?php echo e(__(strip_tags(@$bannerCaption->data_values->description))); ?></p>

                    <div class="btn-area">

                        <?php if(@$bannerCaption->data_values->btn_one_link): ?>
                            <a href="<?php echo e(@$bannerCaption->data_values->btn_one_link); ?>" class="btn btn-primary"><?php echo e(@__($bannerCaption->data_values->btn_one_name)); ?></a>
                        <?php endif; ?>
                        <?php if(@$bannerCaption->data_values->btn_two_link): ?>
                            <a href="<?php echo e(@$bannerCaption->data_values->btn_two_link); ?>" class="btn btn-primary"><?php echo e(@__($bannerCaption->data_values->btn_two_name)); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-5">
                <div class="hero-thumb pulse-animation"><img src="<?php echo e(getImage('assets/images/frontend/banner/'.@$bannerCaption->data_values->image)); ?>" alt="image"></div>
            </div>
        </div>
    </div>
</section>
<!-- hero-section end --><?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/neo_dark/partials/banner.blade.php ENDPATH**/ ?>