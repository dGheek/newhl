<?php echo  tawkto() ?>
<?php echo  analytics() ?><?php /**PATH G:\xampp\htdocs\newhl\secure\core\resources\views/partials/plugins.blade.php ENDPATH**/ ?>