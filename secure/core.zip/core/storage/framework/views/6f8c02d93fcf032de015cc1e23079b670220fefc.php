<section class="inner-hero-section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="inner-hero-content">
                    <h2 class="inner-hero__title text-shadow"><?php echo e(__($page_title)); ?></h2>
                    <ul class="page__breadcums">
                        <li><a href="<?php echo e(url('/')); ?>"><?php echo app('translator')->get('home'); ?></a></li>
                        <li><?php echo e(__($page_title)); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="particles"></div>
</section>
<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset($activeTemplateTrue.'js/particles.min.js')); ?>"></script>
<script src="<?php echo e(asset($activeTemplateTrue.'js/colorJs.php?color='.$general->base_color)); ?>"></script>
<?php $__env->stopPush(); ?><?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/neo_dark/partials/user-breadcrumb.blade.php ENDPATH**/ ?>