<?php if(\App\Models\Plugin::where('act', 'custom-captcha')->where('status', 1)->first()): ?>

    <div class="col-lg-12 form-group custom-form-field d-flex justify-content-center">
        <?php echo  getCustomCaptcha() ?>
    </div>


    <div class="col-lg-12 form-group custom-form-field align-item-center">
        <input type="text" name="captcha" placeholder="<?php echo e(trans('Enter code')); ?>" autocomplete="off" required>
    </div>
<?php endif; ?>


<?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/neo_dark/partials/custom-captcha.blade.php ENDPATH**/ ?>