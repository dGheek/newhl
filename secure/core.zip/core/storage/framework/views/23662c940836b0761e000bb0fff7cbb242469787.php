<?php $__env->startSection('content'); ?>
    <?php echo $__env->make($activeTemplate.'partials.user-breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section class="cmn-section">
        <div class="container">
            <div class="row justify-content-center mt-2">
                <?php for($i = 1; $i <= $lev; $i++): ?>
                    <div class="col-md-2 pb-3">
                        <a href="<?php echo e(route('user.referral.users',$i)); ?>" class="cmn-btn btn-block mb-3 text-center"><?php echo app('translator')->get('Level '.$i); ?></a>
                    </div>
                <?php endfor; ?>
                <div class="col-md-12">
                    <div class="table-responsive--md">
                        <table class="table style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('SL'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Fullname'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Joined At'); ?></th>
                            </tr>
                            </thead>
                            <tbody class="list">
                                <?php echo e(showUserLevel(auth()->user()->id, $lv_no)); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\newhl\secure\core\resources\views/templates/bit_gold/user/my_referral.blade.php ENDPATH**/ ?>