<?php $__env->startSection('content'); ?>
    <?php echo $__env->make($activeTemplate.'partials.user-breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="pt-150">
    <div class="signin-wrapper">
        <div class="outset-circle"></div>
        <div class="container">
            <div class="row justify-content-lg-between align-items-center">
                <div class="col-xl-5 col-lg-6">
                    <div class="signin-thumb"><img src="<?php echo e(asset($activeTemplateTrue.'images/signin.png')); ?>" alt="image"></div>
                </div>
                <div class="col-xl-5 col-lg-6">
                    <div class="signin-form-area">
                        <h3 class="title text-capitalize text-shadow mb-30"><?php echo e(__($page_title)); ?></h3>
                        <form class="signin-form" action="<?php echo e(route('user.login')); ?>" method="post"  onsubmit="return submitUserForm();">
                            <?php echo csrf_field(); ?>
                            <div class="form-group custom-form-field">
                                <i class="fa fa-user"></i>
                                <input type="text" name="username" id="signin_name" placeholder="<?php echo e(trans('username')); ?>" value="<?php echo e(old('username')); ?>" required>
                            </div>

                            <div class="form-group custom-form-field">
                                <i class="fa fa-lock"></i>
                                <input type="password" name="password"  id="signin_pass"  placeholder="<?php echo e(trans('password')); ?>" required autocomplete="current-password" required>
                            </div>


                            <div class="form-group custom-form-field">
                                <?php echo recaptcha() ?>
                            </div>

                            <?php echo $__env->make($activeTemplate.'partials.custom-captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="form-group">
                                <button type="submit" id="recaptcha" class="btn btn-success btn-small w-100 btn-primary"><?php echo e(trans('Sign In')); ?></button>
                            </div>
                            <p><?php echo e(trans('Forgot Your Password?')); ?>

                                <a href="<?php echo e(route('user.password.request')); ?>" class="label-text base--color"><?php echo e(trans('Reset Now')); ?></a>
                            </p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        "use strict";
        function submitUserForm() {
            var response = grecaptcha.getResponse();
            if (response.length == 0) {
                document.getElementById('g-recaptcha-error').innerHTML = '<span style="color:red;"><?php echo app('translator')->get("Captcha field is required."); ?></span>';
                return false;
            }
            return true;
        }
        function verifyCaptcha() {
            document.getElementById('g-recaptcha-error').innerHTML = '';
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/neo_dark/user/auth/login.blade.php ENDPATH**/ ?>