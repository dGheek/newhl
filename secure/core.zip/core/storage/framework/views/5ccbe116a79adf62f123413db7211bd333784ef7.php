<?php $__env->startSection('content'); ?>
    <!-- account section start -->
    <div class="account-section bg_img">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-xl-5 col-lg-7">
            <div class="account-card">
              
              <div class="account-card__body">
                <h2><?php echo app('translator')->get('Reset Password'); ?></h2>
                <form action="<?php echo e(route('user.password.email')); ?>" class="mt-4" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label><?php echo e(trans('Email Address')); ?></label>
                    <input id="email" type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="<?php echo e(trans('Email Address')); ?>" required autocomplete="email" autofocus>
                  </div>
                  <div class="mt-3">
                    <button type="submit" class="cmn-btn"><?php echo app('translator')->get('Send Password Reset Code'); ?></button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- account section end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\newhl\secure\core\resources\views/templates/bit_gold/user/auth/passwords/email.blade.php ENDPATH**/ ?>