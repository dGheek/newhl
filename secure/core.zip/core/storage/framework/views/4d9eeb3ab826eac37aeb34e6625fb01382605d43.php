<?php $__env->startSection('content'); ?>
    <?php echo $__env->make($activeTemplate.'partials.user-breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="pt-60 pb-150">

        <div class="container">
            <div class="row">

                <div class="col-md-12">
                    <div class="right float-right mb-5">
                        <a href="<?php echo e(route('user.deposit.history')); ?>" class="btn cmn-btn">
                            <?php echo app('translator')->get('Deposit History'); ?>                            
                        </a>
                    </div>
                </div>

                <?php $__currentLoopData = $gatewayCurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6 col-md-6 col-sm-12 mb-4">
                    <div class="card">
                        <div class="card-body b-primary">
                            <div class="row justify-content-center">
                                <div class="col-md-5 col-sm-12">
                                    <img src="<?php echo e($data->methodImage()); ?>" class="card-img-top w-100" alt="<?php echo e($data->name); ?>">
                                </div>
                                <div class="col-md-7 col-sm-12">
                                    <ul class="list-group text-center">


                                        <li class="list-group-item">
                                            <?php echo e(__($data->name)); ?></li>

                                        <li class="list-group-item"><?php echo app('translator')->get('Limit'); ?>
                                            : <?php echo e(getAmount($data->min_amount)); ?>

                                            - <?php echo e(getAmount($data->max_amount)); ?> <?php echo e($general->cur_text); ?></li>

                                        <li class="list-group-item"> <?php echo app('translator')->get('Charge'); ?>
                                            - <?php echo e(getAmount($data->fixed_charge)); ?> <?php echo e($general->cur_text); ?>

                                            + <?php echo e(getAmount($data->percent_charge)); ?>%
                                        </li>

                                        <li class="list-group-item">
                                            <button type="button"  data-id="<?php echo e($data->id); ?>" data-resource="<?php echo e($data); ?>"
                                            data-base_symbol="<?php echo e($data->baseSymbol()); ?>"
                                            class=" btn deposit cmn-btn w-100" data-toggle="modal" data-target="#exampleModal">
                                        <?php echo app('translator')->get('Deposit'); ?></button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>



    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-bg">
                <div class="modal-header">
                    <strong class="modal-title method-name text-white" id="exampleModalLabel"></strong>
                    <a href="javascript:void(0)" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
                <form action="<?php echo e(route('user.deposit.insert')); ?>" method="post" class="register">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="currency" class="edit-currency" value="">
                            <input type="hidden" name="method_code" class="edit-method-code" value="">
                        </div>
                            <?php if(session()->get('amount') != null): ?>
                                <input id="amount" type="hidden" class="form-control form-control-lg" name="amount" placeholder="0.00" required autocomplete="off" value="<?php echo e(decrypt(session()->get('amount'))); ?>">
                                <h4 class="text-center"><?php echo app('translator')->get('Please Confirm To Pay'); ?></h4>
                             <?php else: ?>
                        <div class="form-group">
                                <label><?php echo app('translator')->get('Enter Amount'); ?>:</label>
                            <div class="input-group">
                                <input id="amount" type="text" class="form-control form-control-lg" name="amount" placeholder="0.00" required autocomplete="off">
                                <div class="input-group-prepend">
                                    <span class="input-group-text currency-addon addon-bg"><?php echo e($general->cur_text); ?></span>
                                </div>
                            </div>
                        </div>
                            <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-md btn-danger" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn-md cmn-btn"><?php echo app('translator')->get('Next'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function(){
            "use strict";
            $('.deposit').on('click', function () {
                var id = $(this).data('id');
                var result = $(this).data('resource');
                var minAmount = $(this).data('min_amount');
                var maxAmount = $(this).data('max_amount');
                var baseSymbol = "<?php echo e($general->cur_text); ?>";
                var fixCharge = $(this).data('fix_charge');
                var percentCharge = $(this).data('percent_charge');

                var depositLimit = `<?php echo app('translator')->get('Deposit Limit:'); ?> ${minAmount} - ${maxAmount}  ${baseSymbol}`;
                $('.depositLimit').text(depositLimit);
                var depositCharge = `<?php echo app('translator')->get('Charge:'); ?> ${fixCharge} ${baseSymbol}  ${(0 < percentCharge) ? ' + ' +percentCharge + ' % ' : ''}`;
                $('.depositCharge').text(depositCharge);
                $('.method-name').text(`<?php echo app('translator')->get('Payment By '); ?> ${result.name}`);
                $('.currency-addon').text(baseSymbol);

                $('.edit-currency').val(result.currency);
                $('.edit-method-code').val(result.method_code);
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\newhl\secure\core\resources\views/templates/bit_gold/user/payment/deposit.blade.php ENDPATH**/ ?>