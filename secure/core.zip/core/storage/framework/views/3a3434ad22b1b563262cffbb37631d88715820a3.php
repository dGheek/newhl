
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make($activeTemplate.'partials.user-breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section class="cmn-section pt-60">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="right float-md-right float-none text-md-right text-center mb-5">
                        <a href="
                        <?php if(request()->routeIs('user.referral.commissions.deposit')): ?>
                        javascript:void(0)
                        <?php else: ?>
                        <?php echo e(route('user.referral.commissions.deposit')); ?>

                        <?php endif; ?>

                        " class="btn cmn-btn mb-md-0 mb-2 
                        <?php if(request()->routeIs('user.referral.commissions.deposit')): ?>
                        btn-disabled
                        <?php endif; ?>
                        ">
                            <?php echo app('translator')->get('Deposit Commission'); ?>                            
                        </a>
                        <a href="

                        <?php if(request()->routeIs('user.referral.commissions.interest')): ?>
                        javascript:void(0)
                        <?php else: ?>
                        <?php echo e(route('user.referral.commissions.interest')); ?>

                        <?php endif; ?>

                        " class="btn cmn-btn mb-md-0 mb-2
                        <?php if(request()->routeIs('user.referral.commissions.interest')): ?>
                        btn-disabled
                        <?php endif; ?>
                        ">
                            <?php echo app('translator')->get('Interest Commission'); ?>                            
                        </a>
                        <a href="

                        <?php if(request()->routeIs('user.referral.commissions.invest')): ?>
                        javascript:void(0)
                        <?php else: ?>
                        <?php echo e(route('user.referral.commissions.invest')); ?>

                        <?php endif; ?>

                        " class="btn cmn-btn mb-md-0
                        <?php if(request()->routeIs('user.referral.commissions.invest')): ?>
                        btn-disabled
                        <?php endif; ?>
                        ">
                            <?php echo app('translator')->get('Invest Commission'); ?>                            
                        </a>
                    </div>
                </div>
            	<div class="col-md-12">
                    <div class="table-responsive--md">
                        <table class="table style--two">
                            <thead>
                            <tr>
                                <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('From'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Level'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Percent'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Amount'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('Type'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr <?php if($data->amount < 0): ?> class="halka-golapi" <?php endif; ?>>
                                    <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e(showDateTime($data->created_at,'d M, Y')); ?></td>
                                    <td data-label="<?php echo app('translator')->get('From'); ?>"><strong><?php echo e(@$data->bywho->username); ?></strong></td>
                                    <td data-label="<?php echo app('translator')->get('Level'); ?>"><?php echo e(__(ordinal($data->level))); ?> <?php echo app('translator')->get('Level'); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Percent'); ?>"><?php echo e(getAmount($data->percent)); ?> %</td>
                                    <td data-label="<?php echo app('translator')->get('Amount'); ?>"><?php echo e(__($general->cur_sym)); ?> <?php echo e(getAmount($data->commission_amount)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Type'); ?>"><?php echo e(__($data->type)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-right" colspan="100%"><?php echo e(__($empty_message)); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($logs->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate.'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\hyplab\core\resources\views/templates/bit_gold/user/referral_commissions.blade.php ENDPATH**/ ?>